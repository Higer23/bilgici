# Changelog

## [3.0.0] - 2026-02-12

### Added
- WebGPU fingerprinting module
- Battery Status API profiling
- Network Information API
- Generic Sensor API support
- Web Bluetooth & USB APIs
- Clipboard API profiling
- Service Worker detection
- Storage APIs profiling
- Credential Management API
- Payment Request API
- Machine Learning integration with TensorFlow.js
- Statistical analysis module
- Privacy-preserving analytics
- Comprehensive test suite
- CI/CD pipeline
- Enhanced documentation
