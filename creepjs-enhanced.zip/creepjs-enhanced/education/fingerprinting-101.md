# Browser Fingerprinting 101

## What is Browser Fingerprinting?

Browser fingerprinting is a technique to identify unique users based on their browser and device characteristics.

## How It Works

1. **Data Collection**: Gather browser/device properties
2. **Hash Generation**: Create unique identifier
3. **Tracking**: Recognize returning users

## Common Techniques

- Canvas fingerprinting
- WebGL fingerprinting
- Audio context fingerprinting
- Font enumeration
- Screen resolution
- Timezone & language
- Hardware concurrency

## Privacy Implications

Users should be aware of fingerprinting and use privacy tools if desired.
