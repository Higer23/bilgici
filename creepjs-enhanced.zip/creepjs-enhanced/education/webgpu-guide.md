# WebGPU Fingerprinting Guide

## Overview

WebGPU provides detailed GPU information that can uniquely identify devices.

## Data Collected

- GPU vendor & model
- Adapter features
- Texture format support
- Compute capabilities
- Performance metrics

## Implementation

See src/webgpu/index.ts for full implementation.
