import React, { useEffect, useState } from 'react'
import { getFingerprint } from 'creepjs-enhanced'

function FingerprintComponent() {
  const [fp, setFp] = useState(null)
  
  useEffect(() => {
    getFingerprint().then(setFp)
  }, [])
  
  if (!fp) return <div>Loading...</div>
  
  return (
    <div>
      <h2>Your Fingerprint</h2>
      <p>Hash: {fp.hash}</p>
      <p>WebGPU: {fp.webgpu?.supported ? 'Yes' : 'No'}</p>
      <p>Bot Probability: {(fp.ml?.botProbability * 100).toFixed(1)}%</p>
    </div>
  )
}

export default FingerprintComponent
