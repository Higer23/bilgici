# CreepJS Enhanced 🔍

Enterprise-grade browser fingerprinting with WebGPU, ML, Battery API, and 20+ advanced modules.

## Features
- ✨ WebGPU, Battery, Network, Sensors, Bluetooth/USB, Clipboard APIs
- 🤖 ML browser clustering with TensorFlow.js
- 🛡️ Enhanced privacy detection (Brave/Firefox/Tor bypass)
- 📊 Statistical analysis & uniqueness scoring  
- 🧪 Comprehensive test suite (Jest + Playwright)
- ⚡ Performance optimized with Web Workers
- 📦 TypeScript strict mode
- 🔄 CI/CD with GitHub Actions

## Quick Start
```bash
npm install creepjs-enhanced
```

```javascript
import { getFingerprint } from 'creepjs-enhanced'
const fp = await getFingerprint()
console.log('Hash:', fp.hash)
console.log('WebGPU:', fp.webgpu)
console.log('ML Analysis:', fp.ml)
```

See full documentation in /docs
