/**
 * Express.js Backend API for CreepJS
 */
const express = require('express')
const cors = require('cors')
const helmet = require('helmet')
const rateLimit = require('express-rate-limit')

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(helmet())
app.use(cors())
app.use(express.json())

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
})
app.use('/api/', limiter)

// Routes
app.post('/api/fingerprint', async (req, res) => {
  try {
    const { fingerprint } = req.body
    // Store fingerprint in database
    res.json({ success: true, id: 'fp_' + Date.now() })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.get('/api/stats', async (req, res) => {
  res.json({
    total: 1000000,
    unique: 950000,
    bots: 50000
  })
})

app.listen(PORT, () => {
  console.log(`CreepJS API running on port ${PORT}`)
})
