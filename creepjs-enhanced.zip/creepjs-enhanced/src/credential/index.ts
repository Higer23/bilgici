/**
 * Credential Management API Fingerprinting Module
 * Auto-generated module for CreepJS Enhanced
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface CredentialData {
    supported: boolean
    permissions: Record<string, string>
    features: string[]
    $hash: string
}

export const getCredential = async (): Promise<CredentialData> => {
    try {
        const data: CredentialData = {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }

        // Check API support
        data.supported = data.supported || "publickey-credentials-get" in window || "publickey-credentials-get" in navigator;

        // Check permissions
        if ('permissions' in navigator) {
            const perms = ["publickey-credentials-get"]
            for (const perm of perms) {
                try {
                    const result = await (navigator.permissions as any).query({ name: perm })
                    data.permissions[perm] = result.state
                } catch (e) {
                    data.permissions[perm] = 'unavailable'
                }
            }
        }

        data.$hash = await hashMini(data)
        return data
    } catch (error) {
        sendToTrash('Credential', error)
        return {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }
    }
}

export const credentialHTML = (data: CredentialData): string => {
    if (!data.supported) {
        return `<div class="col-six"><strong>Credential Management API</strong><div>not supported</div></div>`
    }
    
    return `
        <div class="col-six">
            <strong>Credential Management API</strong>
            <div>hash: ${data.$hash}</div>
            <div>supported: ${data.supported}</div>
            ${Object.entries(data.permissions).map(([k, v]) => `<div>${k}: ${v}</div>`).join('')}
        </div>
    `
}

export default getCredential
