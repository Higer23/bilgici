/**
 * Battery Status API Fingerprinting Module
 * Profiles device battery characteristics and behavior patterns
 * Detects privacy mode, fake data, mobile/desktop classification
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

// Types
export interface BatteryData {
	supported: boolean
	charging: boolean
	chargingTime: number
	dischargingTime: number
	level: number
	timestamp: number
	privacyMode: boolean
	fakeDataDetected: boolean
	deviceType: 'mobile' | 'desktop' | 'unknown'
	behaviorProfile: {
		levelChanges: number[]
		chargingPattern: string
		timeSeriesAnomaly: boolean
	}
	$hash: string
	lied: boolean
}

// Detect Battery API Support
const detectBatterySupport = (): boolean => {
	try {
		return 'getBattery' in navigator || 'battery' in navigator
	} catch (error) {
		return false
	}
}

// Get Battery Manager
const getBatteryManager = async (): Promise<any | null> => {
	try {
		if ('getBattery' in navigator) {
			return await (navigator as any).getBattery()
		}
		if ('battery' in navigator) {
			return (navigator as any).battery
		}
		return null
	} catch (error) {
		sendToTrash('Battery Manager', error)
		return null
	}
}

// Detect Privacy Mode (API blocked)
const detectPrivacyMode = (battery: any): boolean => {
	try {
		// If battery always returns same values, likely blocked
		if (battery.level === 1 && battery.chargingTime === Infinity && 
		    battery.dischargingTime === Infinity && battery.charging === true) {
			return true
		}
		
		// Firefox privacy.resistFingerprinting blocks with these values
		if (battery.level === 1 && battery.charging === false && 
		    battery.chargingTime === 0 && battery.dischargingTime === Infinity) {
			return true
		}
		
		return false
	} catch (error) {
		return false
	}
}

// Detect Fake Data Patterns
const detectFakeData = (battery: any): boolean => {
	try {
		const suspiciousPatterns: string[] = []
		
		// Suspiciously round numbers
		if (battery.level === 1.0 || battery.level === 0.5 || battery.level === 0.75) {
			suspiciousPatterns.push('Round level values')
		}
		
		// Impossible combinations
		if (battery.charging && battery.chargingTime === Infinity) {
			suspiciousPatterns.push('Charging with infinite time')
		}
		
		if (!battery.charging && battery.dischargingTime === 0) {
			suspiciousPatterns.push('Not charging with zero discharge time')
		}
		
		// Desktop masquerading as mobile
		if (battery.level === 1 && battery.charging === true && 
		    battery.chargingTime === 0 && battery.dischargingTime === Infinity) {
			suspiciousPatterns.push('Likely AC-powered (desktop)')
		}
		
		return suspiciousPatterns.length > 0
	} catch (error) {
		return false
	}
}

// Classify Device Type
const classifyDeviceType = (battery: any): 'mobile' | 'desktop' | 'unknown' => {
	try {
		// Desktop typically: always charging, level = 1, infinite discharge
		if (battery.level === 1 && battery.charging === true && 
		    battery.dischargingTime === Infinity) {
			return 'desktop'
		}
		
		// Mobile: variable level, finite discharge time
		if (battery.level < 1 && battery.dischargingTime < Infinity && 
		    battery.dischargingTime > 0) {
			return 'mobile'
		}
		
		// Laptop: charging but not always at 100%
		if (battery.charging && battery.level < 1) {
			return 'mobile' // Treat laptops as mobile
		}
		
		return 'unknown'
	} catch (error) {
		return 'unknown'
	}
}

// Time Series Analysis for Behavior Profiling
const analyzeBehaviorPattern = (battery: any): {
	levelChanges: number[]
	chargingPattern: string
	timeSeriesAnomaly: boolean
} => {
	try {
		// This would ideally track changes over time
		// For now, we capture a snapshot
		const levelChanges: number[] = [battery.level]
		
		let chargingPattern = 'unknown'
		if (battery.charging) {
			chargingPattern = battery.chargingTime === Infinity ? 'ac-powered' : 'charging'
		} else {
			chargingPattern = battery.dischargingTime === Infinity ? 'full-battery' : 'discharging'
		}
		
		// Detect anomalies
		const timeSeriesAnomaly = 
			(battery.level === 0 && battery.charging === false) || // Dead battery
			(battery.level > 1 || battery.level < 0) || // Out of range
			(battery.chargingTime < 0 || battery.dischargingTime < 0) // Negative times
		
		return {
			levelChanges,
			chargingPattern,
			timeSeriesAnomaly,
		}
	} catch (error) {
		return {
			levelChanges: [],
			chargingPattern: 'unknown',
			timeSeriesAnomaly: false,
		}
	}
}

// Event Tracking (would be set up for long-term monitoring)
const setupBatteryEventTracking = (battery: any, callback: (event: string) => void): void => {
	try {
		battery.addEventListener('chargingchange', () => {
			callback('chargingchange')
		})
		
		battery.addEventListener('chargingtimechange', () => {
			callback('chargingtimechange')
		})
		
		battery.addEventListener('dischargingtimechange', () => {
			callback('dischargingtimechange')
		})
		
		battery.addEventListener('levelchange', () => {
			callback('levelchange')
		})
	} catch (error) {
		sendToTrash('Battery events', error)
	}
}

// Main Battery Fingerprinting Function
export const getBattery = async (): Promise<BatteryData> => {
	try {
		const timer = createTimer()
		timer.start()
		
		const supported = detectBatterySupport()
		
		if (!supported) {
			return {
				supported: false,
				charging: false,
				chargingTime: 0,
				dischargingTime: 0,
				level: 0,
				timestamp: timer.stop(),
				privacyMode: false,
				fakeDataDetected: false,
				deviceType: 'unknown',
				behaviorProfile: {
					levelChanges: [],
					chargingPattern: 'unknown',
					timeSeriesAnomaly: false,
				},
				$hash: '',
				lied: false,
			}
		}
		
		const battery = await getBatteryManager()
		
		if (!battery) {
			return {
				supported: true,
				charging: false,
				chargingTime: 0,
				dischargingTime: 0,
				level: 0,
				timestamp: timer.stop(),
				privacyMode: true,
				fakeDataDetected: false,
				deviceType: 'unknown',
				behaviorProfile: {
					levelChanges: [],
					chargingPattern: 'unknown',
					timeSeriesAnomaly: false,
				},
				$hash: '',
				lied: true,
			}
		}
		
		const privacyMode = detectPrivacyMode(battery)
		const fakeDataDetected = detectFakeData(battery)
		const deviceType = classifyDeviceType(battery)
		const behaviorProfile = analyzeBehaviorPattern(battery)
		
		const batteryData: BatteryData = {
			supported: true,
			charging: battery.charging,
			chargingTime: battery.chargingTime,
			dischargingTime: battery.dischargingTime,
			level: battery.level,
			timestamp: timer.stop(),
			privacyMode,
			fakeDataDetected,
			deviceType,
			behaviorProfile,
			$hash: '',
			lied: privacyMode || fakeDataDetected,
		}
		
		// Calculate hash
		const hash = await hashMini({
			charging: battery.charging,
			deviceType,
			behaviorPattern: behaviorProfile.chargingPattern,
		})
		
		batteryData.$hash = hash
		
		return batteryData
	} catch (error) {
		sendToTrash('Battery', error)
		return {
			supported: false,
			charging: false,
			chargingTime: 0,
			dischargingTime: 0,
			level: 0,
			timestamp: 0,
			privacyMode: false,
			fakeDataDetected: false,
			deviceType: 'unknown',
			behaviorProfile: {
				levelChanges: [],
				chargingPattern: 'unknown',
				timeSeriesAnomaly: false,
			},
			$hash: '',
			lied: false,
		}
	}
}

// HTML Output Function
export const batteryHTML = (batteryData: BatteryData): string => {
	if (!batteryData || !batteryData.supported) {
		return `<div class="col-six">
			<strong>Battery</strong>
			<div>not supported</div>
		</div>`
	}
	
	const {
		charging,
		chargingTime,
		dischargingTime,
		level,
		privacyMode,
		fakeDataDetected,
		deviceType,
		behaviorProfile,
		$hash,
		lied,
	} = batteryData
	
	return `
		<div class="col-six">
			<strong>Battery</strong>${lied ? ' <span class="lies">lies</span>' : ''}
			<div>hash: ${$hash}</div>
			<div class="block-text">
				<div>device: ${deviceType}</div>
				<div>charging: ${charging}</div>
				<div>level: ${(level * 100).toFixed(1)}%</div>
				${charging ? `<div>charging time: ${chargingTime === Infinity ? '∞' : chargingTime + 's'}</div>` : ''}
				${!charging ? `<div>discharging time: ${dischargingTime === Infinity ? '∞' : dischargingTime + 's'}</div>` : ''}
				<div>pattern: ${behaviorProfile.chargingPattern}</div>
				${privacyMode ? '<div class="lies">privacy mode detected</div>' : ''}
				${fakeDataDetected ? '<div class="lies">fake data detected</div>' : ''}
			</div>
		</div>
	`
}

export default getBattery
