/**
 * Storage APIs Fingerprinting Module
 * Auto-generated module for CreepJS Enhanced
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface StorageData {
    supported: boolean
    permissions: Record<string, string>
    features: string[]
    $hash: string
}

export const getStorage = async (): Promise<StorageData> => {
    try {
        const data: StorageData = {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }

        // Check API support
        data.supported = data.supported || "persistent-storage" in window || "persistent-storage" in navigator;

        // Check permissions
        if ('permissions' in navigator) {
            const perms = ["persistent-storage"]
            for (const perm of perms) {
                try {
                    const result = await (navigator.permissions as any).query({ name: perm })
                    data.permissions[perm] = result.state
                } catch (e) {
                    data.permissions[perm] = 'unavailable'
                }
            }
        }

        data.$hash = await hashMini(data)
        return data
    } catch (error) {
        sendToTrash('Storage', error)
        return {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }
    }
}

export const storageHTML = (data: StorageData): string => {
    if (!data.supported) {
        return `<div class="col-six"><strong>Storage APIs</strong><div>not supported</div></div>`
    }
    
    return `
        <div class="col-six">
            <strong>Storage APIs</strong>
            <div>hash: ${data.$hash}</div>
            <div>supported: ${data.supported}</div>
            ${Object.entries(data.permissions).map(([k, v]) => `<div>${k}: ${v}</div>`).join('')}
        </div>
    `
}

export default getStorage
