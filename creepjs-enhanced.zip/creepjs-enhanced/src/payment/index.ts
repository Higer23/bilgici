/**
 * Payment Request API Fingerprinting Module
 * Auto-generated module for CreepJS Enhanced
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface PaymentData {
    supported: boolean
    permissions: Record<string, string>
    features: string[]
    $hash: string
}

export const getPayment = async (): Promise<PaymentData> => {
    try {
        const data: PaymentData = {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }

        // Check API support
        data.supported = data.supported || "payment-handler" in window || "payment-handler" in navigator;

        // Check permissions
        if ('permissions' in navigator) {
            const perms = ["payment-handler"]
            for (const perm of perms) {
                try {
                    const result = await (navigator.permissions as any).query({ name: perm })
                    data.permissions[perm] = result.state
                } catch (e) {
                    data.permissions[perm] = 'unavailable'
                }
            }
        }

        data.$hash = await hashMini(data)
        return data
    } catch (error) {
        sendToTrash('Payment', error)
        return {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }
    }
}

export const paymentHTML = (data: PaymentData): string => {
    if (!data.supported) {
        return `<div class="col-six"><strong>Payment Request API</strong><div>not supported</div></div>`
    }
    
    return `
        <div class="col-six">
            <strong>Payment Request API</strong>
            <div>hash: ${data.$hash}</div>
            <div>supported: ${data.supported}</div>
            ${Object.entries(data.permissions).map(([k, v]) => `<div>${k}: ${v}</div>`).join('')}
        </div>
    `
}

export default getPayment
