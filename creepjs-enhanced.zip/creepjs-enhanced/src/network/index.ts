/**
 * Network Information API Fingerprinting
 * Profiles network connection characteristics, VPN detection hints
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface NetworkData {
	supported: boolean
	effectiveType: string
	downlink: number
	rtt: number
	saveData: boolean
	type: string
	vpnHints: string[]
	$hash: string
}

export const getNetwork = async (): Promise<NetworkData> => {
	try {
		const connection = (navigator as any).connection || 
		                  (navigator as any).mozConnection || 
		                  (navigator as any).webkitConnection
		
		if (!connection) {
			return {
				supported: false,
				effectiveType: '',
				downlink: 0,
				rtt: 0,
				saveData: false,
				type: '',
				vpnHints: [],
				$hash: ''
			}
		}

		const vpnHints: string[] = []
		
		// VPN detection heuristics
		if (connection.rtt && connection.rtt > 100) {
			vpnHints.push('high-rtt')
		}
		if (connection.downlink && connection.downlink < 1) {
			vpnHints.push('low-bandwidth')
		}

		const data: NetworkData = {
			supported: true,
			effectiveType: connection.effectiveType || '',
			downlink: connection.downlink || 0,
			rtt: connection.rtt || 0,
			saveData: connection.saveData || false,
			type: connection.type || '',
			vpnHints,
			$hash: ''
		}

		data.$hash = await hashMini(data)
		return data
	} catch (error) {
		sendToTrash('Network', error)
		return {
			supported: false,
			effectiveType: '',
			downlink: 0,
			rtt: 0,
			saveData: false,
			type: '',
			vpnHints: [],
			$hash: ''
		}
	}
}

export const networkHTML = (data: NetworkData): string => {
	if (!data.supported) return '<div class="col-six"><strong>Network</strong><div>not supported</div></div>'
	
	return `
		<div class="col-six">
			<strong>Network</strong>
			<div>hash: ${data.$hash}</div>
			<div>type: ${data.type}</div>
			<div>effective: ${data.effectiveType}</div>
			<div>downlink: ${data.downlink} Mbps</div>
			<div>rtt: ${data.rtt} ms</div>
			<div>save data: ${data.saveData}</div>
			${data.vpnHints.length > 0 ? `<div>vpn hints: ${data.vpnHints.join(', ')}</div>` : ''}
		</div>
	`
}

export default getNetwork
