/**
 * Web Bluetooth API Fingerprinting Module
 * Auto-generated module for CreepJS Enhanced
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface BluetoothData {
    supported: boolean
    permissions: Record<string, string>
    features: string[]
    $hash: string
}

export const getBluetooth = async (): Promise<BluetoothData> => {
    try {
        const data: BluetoothData = {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }

        // Check API support
        data.supported = data.supported || "bluetooth" in window || "bluetooth" in navigator;

        // Check permissions
        if ('permissions' in navigator) {
            const perms = ["bluetooth"]
            for (const perm of perms) {
                try {
                    const result = await (navigator.permissions as any).query({ name: perm })
                    data.permissions[perm] = result.state
                } catch (e) {
                    data.permissions[perm] = 'unavailable'
                }
            }
        }

        data.$hash = await hashMini(data)
        return data
    } catch (error) {
        sendToTrash('Bluetooth', error)
        return {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }
    }
}

export const bluetoothHTML = (data: BluetoothData): string => {
    if (!data.supported) {
        return `<div class="col-six"><strong>Web Bluetooth API</strong><div>not supported</div></div>`
    }
    
    return `
        <div class="col-six">
            <strong>Web Bluetooth API</strong>
            <div>hash: ${data.$hash}</div>
            <div>supported: ${data.supported}</div>
            ${Object.entries(data.permissions).map(([k, v]) => `<div>${k}: ${v}</div>`).join('')}
        </div>
    `
}

export default getBluetooth
