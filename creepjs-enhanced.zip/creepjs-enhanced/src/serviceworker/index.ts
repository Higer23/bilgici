/**
 * Service Worker API Fingerprinting Module
 * Auto-generated module for CreepJS Enhanced
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface ServiceworkerData {
    supported: boolean
    permissions: Record<string, string>
    features: string[]
    $hash: string
}

export const getServiceworker = async (): Promise<ServiceworkerData> => {
    try {
        const data: ServiceworkerData = {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }

        // Check API support
        data.supported = data.supported || "service-worker" in window || "service-worker" in navigator;

        // Check permissions
        if ('permissions' in navigator) {
            const perms = ["service-worker"]
            for (const perm of perms) {
                try {
                    const result = await (navigator.permissions as any).query({ name: perm })
                    data.permissions[perm] = result.state
                } catch (e) {
                    data.permissions[perm] = 'unavailable'
                }
            }
        }

        data.$hash = await hashMini(data)
        return data
    } catch (error) {
        sendToTrash('Serviceworker', error)
        return {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }
    }
}

export const serviceworkerHTML = (data: ServiceworkerData): string => {
    if (!data.supported) {
        return `<div class="col-six"><strong>Service Worker API</strong><div>not supported</div></div>`
    }
    
    return `
        <div class="col-six">
            <strong>Service Worker API</strong>
            <div>hash: ${data.$hash}</div>
            <div>supported: ${data.supported}</div>
            ${Object.entries(data.permissions).map(([k, v]) => `<div>${k}: ${v}</div>`).join('')}
        </div>
    `
}

export default getServiceworker
