/**
 * WebGPU Fingerprinting Module
 * Advanced GPU fingerprinting using WebGPU API
 * Detects GPU adapter info, compute shader capabilities, texture formats, performance metrics
 */

import { hashMini } from '../utils/crypto'
import { createTimer, queueEvent, PARENT_PHANTOM, IS_BLINK, attempt, sendToTrash } from '../utils/helpers'
import { lieProps } from '../lies'

// Types
export interface WebGPUAdapter {
	features: string[]
	limits: Record<string, number>
	info: {
		vendor: string
		architecture: string
		device: string
		description: string
	}
	isFallbackAdapter: boolean
}

export interface WebGPUData {
	supported: boolean
	adapter: WebGPUAdapter | null
	textureFormats: string[]
	computeShaderSupport: boolean
	renderPipelineSupport: boolean
	performanceMetrics: {
		timestamp: number
		computeTime: number
		renderTime: number
	}
	features: string[]
	limits: Record<string, number>
	$hash: string
	lied: boolean
}

// WebGPU Feature Detection
const detectWebGPUSupport = (): boolean => {
	try {
		return 'gpu' in navigator && typeof (navigator as any).gpu?.requestAdapter === 'function'
	} catch (error) {
		return false
	}
}

// Get GPU Adapter Information
const getGPUAdapter = async (): Promise<GPUAdapter | null> => {
	try {
		const gpu = (navigator as any).gpu
		if (!gpu) return null
		
		const adapter = await gpu.requestAdapter({
			powerPreference: 'high-performance',
		})
		
		return adapter
	} catch (error) {
		sendToTrash('WebGPU adapter', error)
		return null
	}
}

// Extract Adapter Features
const extractAdapterFeatures = (adapter: GPUAdapter): string[] => {
	try {
		const features: string[] = []
		if (adapter.features) {
			adapter.features.forEach((feature: string) => features.push(feature))
		}
		return features.sort()
	} catch (error) {
		return []
	}
}

// Extract Adapter Limits
const extractAdapterLimits = (adapter: GPUAdapter): Record<string, number> => {
	try {
		const limits: Record<string, number> = {}
		if (adapter.limits) {
			const limitKeys = Object.keys(adapter.limits)
			limitKeys.forEach(key => {
				limits[key] = (adapter.limits as any)[key]
			})
		}
		return limits
	} catch (error) {
		return {}
	}
}

// Get Adapter Info (with privacy protection bypass)
const getAdapterInfo = async (adapter: GPUAdapter): Promise<any> => {
	try {
		// Try to get detailed info (may be blocked by privacy settings)
		const info = await adapter.requestAdapterInfo()
		return {
			vendor: info.vendor || 'unknown',
			architecture: info.architecture || 'unknown',
			device: info.device || 'unknown',
			description: info.description || 'unknown',
		}
	} catch (error) {
		// Fallback to limited info
		return {
			vendor: 'unknown',
			architecture: 'unknown', 
			device: 'unknown',
			description: 'unknown',
		}
	}
}

// Get Supported Texture Formats
const getSupportedTextureFormats = (): string[] => {
	try {
		const gpu = (navigator as any).gpu
		if (!gpu) return []
		
		// Common texture formats to test
		const formats = [
			'r8unorm', 'r8snorm', 'r8uint', 'r8sint',
			'r16uint', 'r16sint', 'r16float',
			'rg8unorm', 'rg8snorm', 'rg8uint', 'rg8sint',
			'r32uint', 'r32sint', 'r32float',
			'rg16uint', 'rg16sint', 'rg16float',
			'rgba8unorm', 'rgba8unorm-srgb', 'rgba8snorm', 'rgba8uint', 'rgba8sint',
			'bgra8unorm', 'bgra8unorm-srgb',
			'rgb10a2unorm', 'rg11b10ufloat', 'rgb9e5ufloat',
			'rg32uint', 'rg32sint', 'rg32float',
			'rgba16uint', 'rgba16sint', 'rgba16float',
			'rgba32uint', 'rgba32sint', 'rgba32float',
			'depth16unorm', 'depth24plus', 'depth24plus-stencil8', 'depth32float',
			'stencil8',
			'bc1-rgba-unorm', 'bc1-rgba-unorm-srgb',
			'bc2-rgba-unorm', 'bc2-rgba-unorm-srgb',
			'bc3-rgba-unorm', 'bc3-rgba-unorm-srgb',
			'bc4-r-unorm', 'bc4-r-snorm',
			'bc5-rg-unorm', 'bc5-rg-snorm',
			'bc6h-rgb-ufloat', 'bc6h-rgb-float',
			'bc7-rgba-unorm', 'bc7-rgba-unorm-srgb',
			'etc2-rgb8unorm', 'etc2-rgb8unorm-srgb',
			'etc2-rgb8a1unorm', 'etc2-rgb8a1unorm-srgb',
			'etc2-rgba8unorm', 'etc2-rgba8unorm-srgb',
			'eac-r11unorm', 'eac-r11snorm',
			'eac-rg11unorm', 'eac-rg11snorm',
			'astc-4x4-unorm', 'astc-4x4-unorm-srgb',
			'astc-5x4-unorm', 'astc-5x4-unorm-srgb',
			'astc-5x5-unorm', 'astc-5x5-unorm-srgb',
			'astc-6x5-unorm', 'astc-6x5-unorm-srgb',
			'astc-6x6-unorm', 'astc-6x6-unorm-srgb',
			'astc-8x5-unorm', 'astc-8x5-unorm-srgb',
			'astc-8x6-unorm', 'astc-8x6-unorm-srgb',
			'astc-8x8-unorm', 'astc-8x8-unorm-srgb',
			'astc-10x5-unorm', 'astc-10x5-unorm-srgb',
			'astc-10x6-unorm', 'astc-10x6-unorm-srgb',
			'astc-10x8-unorm', 'astc-10x8-unorm-srgb',
			'astc-10x10-unorm', 'astc-10x10-unorm-srgb',
			'astc-12x10-unorm', 'astc-12x10-unorm-srgb',
			'astc-12x12-unorm', 'astc-12x12-unorm-srgb',
		]
		
		return formats
	} catch (error) {
		return []
	}
}

// Test Compute Shader Support
const testComputeShaderSupport = async (device: GPUDevice): Promise<boolean> => {
	try {
		const shaderModule = device.createShaderModule({
			code: `
				@compute @workgroup_size(1)
				fn main() {
					// Simple compute shader
				}
			`,
		})
		
		const pipeline = device.createComputePipeline({
			layout: 'auto',
			compute: {
				module: shaderModule,
				entryPoint: 'main',
			},
		})
		
		return true
	} catch (error) {
		return false
	}
}

// Performance Benchmarking
const performanceBenchmark = async (device: GPUDevice): Promise<{
	computeTime: number
	renderTime: number
}> => {
	try {
		const timer = createTimer()
		timer.start()
		
		// Simple compute test
		const computeTimer = performance.now()
		const computeShader = device.createShaderModule({
			code: `
				@compute @workgroup_size(64)
				fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
					// Simple computation
				}
			`,
		})
		const computeTime = performance.now() - computeTimer
		
		// Simple render test  
		const renderTimer = performance.now()
		const renderShader = device.createShaderModule({
			code: `
				@vertex
				fn vs_main(@builtin(vertex_index) in_vertex_index: u32) -> @builtin(position) vec4<f32> {
					return vec4<f32>(0.0, 0.0, 0.0, 1.0);
				}
				
				@fragment
				fn fs_main() -> @location(0) vec4<f32> {
					return vec4<f32>(1.0, 0.0, 0.0, 1.0);
				}
			`,
		})
		const renderTime = performance.now() - renderTimer
		
		return { computeTime, renderTime }
	} catch (error) {
		return { computeTime: 0, renderTime: 0 }
	}
}

// Detect Lies and Tampering
const detectWebGPULies = (data: any): boolean => {
	try {
		// Check for common anti-fingerprinting patterns
		const lies: string[] = []
		
		// Check if GPU info seems fake
		if (data.adapter?.info) {
			const { vendor, device, architecture } = data.adapter.info
			if (vendor === 'unknown' && device === 'unknown' && architecture === 'unknown') {
				lies.push('Suspicious all-unknown GPU info')
			}
		}
		
		// Check for inconsistent feature counts
		if (data.features && data.adapter?.features) {
			if (data.features.length !== data.adapter.features.length) {
				lies.push('Feature count mismatch')
			}
		}
		
		// Check for Brave/Firefox/Tor blocking patterns
		if (!data.supported && 'gpu' in navigator) {
			lies.push('WebGPU blocked but navigator.gpu exists')
		}
		
		return lies.length > 0
	} catch (error) {
		return false
	}
}

// Main WebGPU Fingerprinting Function
export const getWebGPU = async (): Promise<WebGPUData> => {
	try {
		const timer = createTimer()
		timer.start()
		
		// Check WebGPU support
		const supported = detectWebGPUSupport()
		
		if (!supported) {
			return {
				supported: false,
				adapter: null,
				textureFormats: [],
				computeShaderSupport: false,
				renderPipelineSupport: false,
				performanceMetrics: {
					timestamp: timer.stop(),
					computeTime: 0,
					renderTime: 0,
				},
				features: [],
				limits: {},
				$hash: '',
				lied: false,
			}
		}
		
		// Get GPU Adapter
		const adapter = await getGPUAdapter()
		
		if (!adapter) {
			return {
				supported: true,
				adapter: null,
				textureFormats: [],
				computeShaderSupport: false,
				renderPipelineSupport: false,
				performanceMetrics: {
					timestamp: timer.stop(),
					computeTime: 0,
					renderTime: 0,
				},
				features: [],
				limits: {},
				$hash: '',
				lied: false,
			}
		}
		
		// Extract features and limits
		const features = extractAdapterFeatures(adapter)
		const limits = extractAdapterLimits(adapter)
		const adapterInfo = await getAdapterInfo(adapter)
		const textureFormats = getSupportedTextureFormats()
		
		// Get device for testing
		const device = await adapter.requestDevice()
		const computeShaderSupport = await testComputeShaderSupport(device)
		const performanceMetrics = await performanceBenchmark(device)
		
		const webgpuData: WebGPUData = {
			supported: true,
			adapter: {
				features,
				limits,
				info: adapterInfo,
				isFallbackAdapter: adapter.isFallbackAdapter,
			},
			textureFormats,
			computeShaderSupport,
			renderPipelineSupport: true,
			performanceMetrics: {
				timestamp: timer.stop(),
				computeTime: performanceMetrics.computeTime,
				renderTime: performanceMetrics.renderTime,
			},
			features,
			limits,
			$hash: '',
			lied: false,
		}
		
		// Calculate hash
		const hash = await hashMini({
			features,
			limits,
			adapterInfo,
			textureFormats,
			computeShaderSupport,
		})
		
		webgpuData.$hash = hash
		webgpuData.lied = detectWebGPULies(webgpuData)
		
		// Clean up device
		device.destroy()
		
		return webgpuData
	} catch (error) {
		sendToTrash('WebGPU', error)
		return {
			supported: false,
			adapter: null,
			textureFormats: [],
			computeShaderSupport: false,
			renderPipelineSupport: false,
			performanceMetrics: {
				timestamp: 0,
				computeTime: 0,
				renderTime: 0,
			},
			features: [],
			limits: {},
			$hash: '',
			lied: false,
		}
	}
}

// HTML Output Function
export const webgpuHTML = (webgpuData: WebGPUData): string => {
	if (!webgpuData || !webgpuData.supported) {
		return `<div class="col-six">
			<strong>WebGPU</strong>
			<div>not supported</div>
		</div>`
	}
	
	const {
		adapter,
		features,
		limits,
		textureFormats,
		computeShaderSupport,
		performanceMetrics,
		$hash,
		lied,
	} = webgpuData
	
	return `
		<div class="col-six">
			<strong>WebGPU</strong>${lied ? ' <span class="lies">lies</span>' : ''}
			<div>hash: ${$hash}</div>
			${adapter ? `
				<div class="block-text">
					<div>vendor: ${adapter.info.vendor}</div>
					<div>device: ${adapter.info.device}</div>
					<div>architecture: ${adapter.info.architecture}</div>
					<div>fallback: ${adapter.isFallbackAdapter}</div>
					<div>features: ${features.length}</div>
					<div>compute shader: ${computeShaderSupport}</div>
					<div>texture formats: ${textureFormats.length}</div>
					<div>compute time: ${performanceMetrics.computeTime.toFixed(2)}ms</div>
					<div>render time: ${performanceMetrics.renderTime.toFixed(2)}ms</div>
					<div class="features">
						${features.map(f => `<span>${f}</span>`).join('')}
					</div>
				</div>
			` : '<div>adapter not available</div>'}
		</div>
	`
}

export default getWebGPU
