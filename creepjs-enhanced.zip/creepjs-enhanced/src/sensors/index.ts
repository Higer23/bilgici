/**
 * Generic Sensor API Fingerprinting Module
 * Auto-generated module for CreepJS Enhanced
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface SensorsData {
    supported: boolean
    permissions: Record<string, string>
    features: string[]
    $hash: string
}

export const getSensors = async (): Promise<SensorsData> => {
    try {
        const data: SensorsData = {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }

        // Check API support
        data.supported = data.supported || "Accelerometer" in window || "Accelerometer" in navigator; data.supported = data.supported || "Gyroscope" in window || "Gyroscope" in navigator; data.supported = data.supported || "Magnetometer" in window || "Magnetometer" in navigator;

        // Check permissions
        if ('permissions' in navigator) {
            const perms = ["Accelerometer", "Gyroscope", "Magnetometer"]
            for (const perm of perms) {
                try {
                    const result = await (navigator.permissions as any).query({ name: perm })
                    data.permissions[perm] = result.state
                } catch (e) {
                    data.permissions[perm] = 'unavailable'
                }
            }
        }

        data.$hash = await hashMini(data)
        return data
    } catch (error) {
        sendToTrash('Sensors', error)
        return {
            supported: false,
            permissions: {},
            features: [],
            $hash: ''
        }
    }
}

export const sensorsHTML = (data: SensorsData): string => {
    if (!data.supported) {
        return `<div class="col-six"><strong>Generic Sensor API</strong><div>not supported</div></div>`
    }
    
    return `
        <div class="col-six">
            <strong>Generic Sensor API</strong>
            <div>hash: ${data.$hash}</div>
            <div>supported: ${data.supported}</div>
            ${Object.entries(data.permissions).map(([k, v]) => `<div>${k}: ${v}</div>`).join('')}
        </div>
    `
}

export default getSensors
