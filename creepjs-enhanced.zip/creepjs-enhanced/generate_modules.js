// Module Generation Script
// This script programmatically creates all the remaining modules

const fs = require('fs');
const path = require('path');

const modules = {
  network: `/**
 * Network Information API Fingerprinting
 * Profiles network connection characteristics
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface NetworkData {
  supported: boolean
  effectiveType: string
  downlink: number
  rtt: number
  saveData: boolean
  type: string
  $hash: string
}

export const getNetwork = async (): Promise<NetworkData> => {
  try {
    const connection = (navigator as any).connection || 
                      (navigator as any).mozConnection || 
                      (navigator as any).webkitConnection
    
    if (!connection) {
      return {
        supported: false,
        effectiveType: '',
        downlink: 0,
        rtt: 0,
        saveData: false,
        type: '',
        $hash: ''
      }
    }

    const data = {
      supported: true,
      effectiveType: connection.effectiveType || '',
      downlink: connection.downlink || 0,
      rtt: connection.rtt || 0,
      saveData: connection.saveData || false,
      type: connection.type || '',
      $hash: ''
    }

    data.$hash = await hashMini(data)
    return data
  } catch (error) {
    sendToTrash('Network', error)
    return {
      supported: false,
      effectiveType: '',
      downlink: 0,
      rtt: 0,
      saveData: false,
      type: '',
      $hash: ''
    }
  }
}

export const networkHTML = (data: NetworkData): string => {
  if (!data.supported) return '<div class="col-six"><strong>Network</strong><div>not supported</div></div>'
  
  return \`
    <div class="col-six">
      <strong>Network</strong>
      <div>hash: \${data.$hash}</div>
      <div>type: \${data.type}</div>
      <div>effective: \${data.effectiveType}</div>
      <div>downlink: \${data.downlink} Mbps</div>
      <div>rtt: \${data.rtt} ms</div>
      <div>save data: \${data.saveData}</div>
    </div>
  \`
}`,

  sensors: `/**
 * Generic Sensor API Fingerprinting
 * Profiles device sensors and their characteristics
 */

import { hashMini } from '../utils/crypto'
import { createTimer, sendToTrash } from '../utils/helpers'

export interface SensorsData {
  accelerometer: boolean
  gyroscope: boolean
  magnetometer: boolean
  ambientLight: boolean
  permissions: Record<string, string>
  $hash: string
}

export const getSensors = async (): Promise<SensorsData> => {
  try {
    const data: SensorsData = {
      accelerometer: 'Accelerometer' in window,
      gyroscope: 'Gyroscope' in window,
      magnetometer: 'Magnetometer' in window,
      ambientLight: 'AmbientLightSensor' in window,
      permissions: {},
      $hash: ''
    }

    // Check permissions
    if ('permissions' in navigator) {
      const perms = ['accelerometer', 'gyroscope', 'magnetometer', 'ambient-light-sensor']
      for (const perm of perms) {
        try {
          const result = await (navigator.permissions as any).query({ name: perm })
          data.permissions[perm] = result.state
        } catch (e) {}
      }
    }

    data.$hash = await hashMini(data)
    return data
  } catch (error) {
    return {
      accelerometer: false,
      gyroscope: false,
      magnetometer: false,
      ambientLight: false,
      permissions: {},
      $hash: ''
    }
  }
}`,

  clipboard: `/**
 * Clipboard API Fingerprinting
 */

import { hashMini } from '../utils/crypto'

export interface ClipboardData {
  supported: boolean
  permissions: { read: string; write: string }
  $hash: string
}

export const getClipboard = async (): Promise<ClipboardData> => {
  try {
    const data: ClipboardData = {
      supported: 'clipboard' in navigator,
      permissions: { read: 'unknown', write: 'unknown' },
      $hash: ''
    }

    if ('permissions' in navigator) {
      try {
        const readPerm = await navigator.permissions.query({ name: 'clipboard-read' as any })
        data.permissions.read = readPerm.state
      } catch (e) {}
      
      try {
        const writePerm = await navigator.permissions.query({ name: 'clipboard-write' as any })
        data.permissions.write = writePerm.state
      } catch (e) {}
    }

    data.$hash = await hashMini(data)
    return data
  } catch (error) {
    return {
      supported: false,
      permissions: { read: 'unknown', write: 'unknown' },
      $hash: ''
    }
  }
}`
};

// Create each module
Object.entries(modules).forEach(([name, code]) => {
  const dir = path.join(__dirname, 'src', name);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(path.join(dir, 'index.ts'), code);
  console.log(\`✓ Created \${name} module\`);
});

console.log('✓ All modules created successfully');
