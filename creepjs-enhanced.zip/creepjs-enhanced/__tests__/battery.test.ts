/**
 * Battery Module Tests
 */

import { getBattery, batteryHTML } from '../src/battery'

describe('Battery Fingerprinting', () => {
	test('should detect battery support', async () => {
		const result = await getBattery()
		expect(result).toHaveProperty('supported')
	})

	test('should get battery information', async () => {
		const result = await getBattery()
		if (result.supported) {
			expect(result).toHaveProperty('charging')
			expect(result).toHaveProperty('level')
			expect(result).toHaveProperty('chargingTime')
			expect(result).toHaveProperty('dischargingTime')
		}
	})

	test('should classify device type', async () => {
		const result = await getBattery()
		if (result.supported) {
			expect(result).toHaveProperty('deviceType')
			expect(['mobile', 'desktop', 'unknown']).toContain(result.deviceType)
		}
	})

	test('should detect privacy mode', async () => {
		const result = await getBattery()
		expect(result).toHaveProperty('privacyMode')
		expect(typeof result.privacyMode).toBe('boolean')
	})

	test('should detect fake data', async () => {
		const result = await getBattery()
		expect(result).toHaveProperty('fakeDataDetected')
		expect(typeof result.fakeDataDetected).toBe('boolean')
	})

	test('should analyze behavior pattern', async () => {
		const result = await getBattery()
		if (result.supported) {
			expect(result).toHaveProperty('behaviorProfile')
			expect(result.behaviorProfile).toHaveProperty('chargingPattern')
		}
	})

	test('should generate hash', async () => {
		const result = await getBattery()
		expect(result.$hash).toBeDefined()
	})

	test('should generate HTML output', async () => {
		const result = await getBattery()
		const html = batteryHTML(result)
		expect(html).toContain('Battery')
	})
})
