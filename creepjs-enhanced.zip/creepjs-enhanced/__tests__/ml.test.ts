import { getMLAnalysis } from '../src/ml'

describe('ML Analysis', () => {
  test('should classify browser', async () => {
    const mockData = { webgl: { supported: true } }
    const result = await getMLAnalysis(mockData)
    expect(result).toHaveProperty('browserCluster')
  })
  
  test('should calculate bot probability', async () => {
    const result = await getMLAnalysis({})
    expect(result.botProbability).toBeGreaterThanOrEqual(0)
    expect(result.botProbability).toBeLessThanOrEqual(1)
  })
})
