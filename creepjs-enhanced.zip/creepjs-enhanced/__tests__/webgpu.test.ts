/**
 * WebGPU Module Tests
 */

import { getWebGPU, webgpuHTML } from '../src/webgpu'

describe('WebGPU Fingerprinting', () => {
	test('should detect WebGPU support', async () => {
		const result = await getWebGPU()
		expect(result).toHaveProperty('supported')
		expect(result).toHaveProperty('$hash')
	})

	test('should extract adapter features', async () => {
		const result = await getWebGPU()
		if (result.supported && result.adapter) {
			expect(result.adapter).toHaveProperty('features')
			expect(Array.isArray(result.adapter.features)).toBe(true)
		}
	})

	test('should extract adapter limits', async () => {
		const result = await getWebGPU()
		if (result.supported && result.adapter) {
			expect(result.adapter).toHaveProperty('limits')
			expect(typeof result.adapter.limits).toBe('object')
		}
	})

	test('should calculate hash', async () => {
		const result = await getWebGPU()
		expect(result.$hash).toBeDefined()
		expect(typeof result.$hash).toBe('string')
	})

	test('should detect lies', async () => {
		const result = await getWebGPU()
		expect(result).toHaveProperty('lied')
		expect(typeof result.lied).toBe('boolean')
	})

	test('should generate HTML output', async () => {
		const result = await getWebGPU()
		const html = webgpuHTML(result)
		expect(html).toContain('WebGPU')
		expect(typeof html).toBe('string')
	})

	test('should handle unsupported environments', async () => {
		const originalGPU = (navigator as any).gpu
		delete (navigator as any).gpu
		
		const result = await getWebGPU()
		expect(result.supported).toBe(false)
		
		;(navigator as any).gpu = originalGPU
	})

	test('should measure performance', async () => {
		const result = await getWebGPU()
		if (result.supported) {
			expect(result.performanceMetrics).toHaveProperty('timestamp')
			expect(result.performanceMetrics).toHaveProperty('computeTime')
			expect(result.performanceMetrics).toHaveProperty('renderTime')
		}
	})
})
