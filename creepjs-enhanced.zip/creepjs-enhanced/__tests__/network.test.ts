import { getNetwork } from '../src/network'

describe('Network API', () => {
  test('should detect network support', async () => {
    const result = await getNetwork()
    expect(result).toHaveProperty('supported')
  })
  
  test('should get connection info', async () => {
    const result = await getNetwork()
    if (result.supported) {
      expect(result).toHaveProperty('effectiveType')
      expect(result).toHaveProperty('downlink')
    }
  })
})
