/**
 * Jest Test Setup
 * Global test configuration and mocks
 */

// Mock WebGPU API
(global as any).navigator = {
	...global.navigator,
	gpu: {
		requestAdapter: jest.fn().mockResolvedValue({
			features: new Set(['texture-compression-bc']),
			limits: { maxTextureDimension2D: 8192 },
			info: {
				vendor: 'test-vendor',
				architecture: 'test-arch',
				device: 'test-device',
				description: 'test-gpu',
			},
			isFallbackAdapter: false,
			requestDevice: jest.fn().mockResolvedValue({
				createShaderModule: jest.fn(),
				createComputePipeline: jest.fn(),
				destroy: jest.fn(),
			}),
			requestAdapterInfo: jest.fn().mockResolvedValue({
				vendor: 'test-vendor',
				architecture: 'test-arch',
				device: 'test-device',
				description: 'test-gpu',
			}),
		}),
	},
}

// Mock Battery API
(global as any).navigator.getBattery = jest.fn().mockResolvedValue({
	charging: false,
	chargingTime: Infinity,
	dischargingTime: 3600,
	level: 0.75,
	addEventListener: jest.fn(),
})

// Mock Network Information API
(global as any).navigator.connection = {
	effectiveType: '4g',
	downlink: 10,
	rtt: 50,
	saveData: false,
	type: 'wifi',
}

// Mock Permissions API
(global as any).navigator.permissions = {
	query: jest.fn().mockResolvedValue({ state: 'granted' }),
}

// Mock Clipboard API
(global as any).navigator.clipboard = {
	readText: jest.fn(),
	writeText: jest.fn(),
}

// Performance mock
global.performance = {
	...global.performance,
	now: jest.fn(() => Date.now()),
}

export {}
