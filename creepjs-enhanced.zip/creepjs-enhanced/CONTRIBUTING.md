# Contributing to CreepJS Enhanced

## Development Setup
1. Fork and clone
2. `npm install`
3. `npm run dev`
4. Make changes
5. `npm test`
6. Submit PR

## Code Standards
- TypeScript strict mode
- 80%+ test coverage
- ESLint passing
- Conventional commits

## Module Guidelines
- Follow existing structure
- Add comprehensive tests
- Update documentation
- Add usage examples
